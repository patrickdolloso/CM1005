### The Game Project 1 – Background scenery ###

Use p5 drawing functions such as rect, ellipse, line, triangle and
point to draw the scenery as set out in the code comments. The items
should appear next to the text titles.

Each bit of scenery is worth two marks:

0 marks = not a reasonable attempt  
1 mark = attempted but it's messy or lacks detail  
2 marks = you've used several shape functions to create the scenery

I've given titles and chosen some base colours, but feel free to
imaginatively modify these and interpret the scenery titles loosely to
match your game theme.

WARNING: Do not get too carried away. If you're shape takes more than 5 lines
of code to draw then you've probably over done it.

** Upload your full project by zipping the folder which includes the p5.min.js, index.html and sketch.js files.  **
