/*

The Game Project 5 - Bring it all together

*/

var gameChar_x;
var gameChar_y;
var floorPos_y;
var scrollPos;
var gameChar_world_x;

var isLeft;
var isRight;
var isFalling;
var isPlummeting;

var trees_x;
var collectables;

function setup()
{
	createCanvas(1024, 576);
	floorPos_y = height * 3/4;
	gameChar_x = width/2;
	gameChar_y = floorPos_y;

	// Variable to control the background scrolling.
	scrollPos = 0;

	// Variable to store the real position of the gameChar in the game
	// world. Needed for collision detection.
	gameChar_world_x = gameChar_x - scrollPos;

	// Boolean variables to control the movement of the game character.
	isLeft = false;
	isRight = false;
	isFalling = false;
	isPlummeting = false;

	// Initialise arrays of scenery objects.
	trees_x = [
		620,
		300,
		500,
		1000,
		450,
		520,
		850,
		1145,
		1600,
		1630,
		1660];

	collectable = [
		{x_pos: 1400, y_pos: floorPos_y, size: 50},
		{x_pos: 190, y_pos: floorPos_y, size: 50},
		{x_pos: 1800, y_pos: floorPos_y, size: 50}];
}

function draw()
{
	background(100, 155, 255); // fill the sky blue

	noStroke();
	fill(0,155,0);
	rect(0, floorPos_y, width, height/4); // draw some green ground

	// Draw clouds.

	// Draw mountains.

	// Draw trees.
	drawTrees()

	// Draw canyons.

	// Draw collectable items.
	for(var i=0; i < collectable.length; i++)
	{
		drawCollectable(collectable[i])
	}

	// Draw game character.
	
	drawGameChar();

	// Logic to make the game character move or the background scroll.
	if(isLeft)
	{
		if(gameChar_x > width * 0.2)
		{
			gameChar_x -= 5;
		}
		else
		{
			scrollPos += 5;
		}
	}

	if(isRight)
	{
		if(gameChar_x < width * 0.8)
		{
			gameChar_x  += 5;
		}
		else
		{
			scrollPos -= 5; // negative for moving against the background
		}
	}

	// Logic to make the game character rise and fall.
	if(gameChar_y < floorPos_y){
		gameChar_y += 5;
		isFalling = true;
	}
	else {
		gameChar_y < floorPos_y;
		isFalling = false;
	}

	// Update real position of gameChar for collision detection.
	gameChar_world_x = gameChar_x - scrollPos;
}


// ---------------------
// Key control functions
// ---------------------

function keyPressed(){

	// if statements to control the animation of the character when
	// keys are pressed.

	//open up the console to see how these work
	console.log("keyPressed: " + key);
	console.log("keyPressed: " + keyCode);

	// Left arrow pressed
	if(keyCode == 37){
		console.log("left arrow");
		isLeft = true;
	}

	// right arrow pressed
	if(keyCode == 39){
		console.log("right arrow");
		isRight = true;
	}

	// spacebar pressed and character on the groud	
	if(keyCode == 32 && gameChar_y == floorPos_y){
		gameChar_y -= 100;		
	}

}

function keyReleased()
{

	// if statements to control the animation of the character when
	// keys are released.

	console.log("keyReleased: " + key);
	console.log("keyReleased: " + keyCode);

	if(keyCode == 37){
		console.log("left arrow");
		isLeft = false;
	}

	if(keyCode == 39){
		console.log("right arrow");
		isRight = false;
	}

	if(keyCode == 32) {
		isFalling = false;
	}

}


// ------------------------------
// Game character render function
// ------------------------------

// Function to draw the game character.

function drawGameChar()
{
	if(isLeft && isFalling)
	{
		// add your jumping-left code
		fill(255,223,196);
		ellipse(gameChar_x, gameChar_y-50, 35);
	
		fill(255,0,0)
		rect(gameChar_x-13,gameChar_y-35,26,30);
	
		fill(0);
		rect(gameChar_x-5,gameChar_y-5,10,10);
	
		ellipse(gameChar_x-5,gameChar_y-55,5);	
		
		fill(255,223,196);
		stroke(0);
		rect(gameChar_x,gameChar_y-55,10,25);
	
		fill(0);
		ellipse(gameChar_x-7,gameChar_y-45,10);
	}
	else if(isRight && isFalling)
	{
		// add your jumping-right code
	fill(255,223,196);
	ellipse(gameChar_x, gameChar_y-50, 35);

	fill(255,0,0)
	rect(gameChar_x-13,gameChar_y-35,26,30);

	fill(0);
	rect(gameChar_x-5,gameChar_y-5,10,10);

	ellipse(gameChar_x+5,gameChar_y-55,5);
	
	fill(255,223,196);
	stroke(0);
	rect(gameChar_x-10,gameChar_y-55,10,25);

	fill(0);
	ellipse(gameChar_x+7,gameChar_y-45,10);


	}
	else if(isLeft)
	{
		// add your walking left code

	fill(255,223,196);
	ellipse(gameChar_x, gameChar_y-50, 35);

	fill(255,0,0)
	rect(gameChar_x-13,gameChar_y-35,26,30);

	fill(0);
	rect(gameChar_x-5,gameChar_y-5,10,10);

	ellipse(gameChar_x-5,gameChar_y-55,5);	
	
	fill(255,223,196);
	stroke(0);
	rect(gameChar_x,gameChar_y-35,10,25);

	fill(0);
	rect(gameChar_x-15,gameChar_y-45,10,2);
	

	}
	else if(isRight)
	{
		// add your walking right code
	fill(255,223,196);
	ellipse(gameChar_x, gameChar_y-50, 35);

	fill(255,0,0)
	rect(gameChar_x-13,gameChar_y-35,26,30);

	fill(0);
	rect(gameChar_x-5,gameChar_y-5,10,10);

	ellipse(gameChar_x+5,gameChar_y-55,5);
	
	fill(255,223,196);
	stroke(0);
	rect(gameChar_x-10,gameChar_y-35,10,25);

	fill(0);
	rect(gameChar_x+5,gameChar_y-45,10,2);


	}
	else if(isFalling || isPlummeting)
	{
		// add your jumping facing forwards code
		fill(255,223,196);
		ellipse(gameChar_x, gameChar_y-50, 35);
	
		fill(255,0,0)
		rect(gameChar_x-13,gameChar_y-35,26,30);
	
		fill(0);
		rect(gameChar_x-15,gameChar_y-5,10,10);
	
		fill(0);
		rect(gameChar_x+5,gameChar_y-5,10,10);
	
		ellipse(gameChar_x-5,gameChar_y-55,5);
		ellipse(gameChar_x+5,gameChar_y-55,5);
	
		ellipse(gameChar_x,gameChar_y-45,15);
		
		fill(255,223,196);
		stroke(0);
		rect(gameChar_x-20,gameChar_y-55,10,25);
		rect(gameChar_x+10,gameChar_y-55,10,25);
		

	}
	else
	{
		// add your standing front facing code
		fill(255,223,196);
		ellipse(gameChar_x, gameChar_y-50, 35);
	
		fill(255,0,0)
		rect(gameChar_x-13,gameChar_y-35,26,30);
	
		fill(0);
		rect(gameChar_x-15,gameChar_y-5,10,10);
	
		fill(0);
		rect(gameChar_x+5,gameChar_y-5,10,10);
	
	
		ellipse(gameChar_x-5,gameChar_y-55,5);
		ellipse(gameChar_x+5,gameChar_y-55,5);
	
		rect(gameChar_x-7,gameChar_y-45,15,2);
		
		fill(255,223,196);
		stroke(0)
		rect(gameChar_x-20,gameChar_y-35,10,25);
		rect(gameChar_x+10,gameChar_y-35,10,25);
	
	}
}

// ---------------------------
// Background render functions
// ---------------------------

// Function to draw cloud objects.

// Function to draw mountains objects.

// Function to draw trees objects.
function drawTrees()
{
	for(var i = 0; i < trees_x.length; i++){
		stroke(0);
		fill(106, 83, 47);
		rect(trees_x[i],floorPos_y,20,-55);
		fill(85,107,47)
		triangle(trees_x[i]+10,floorPos_y-150,trees_x[i]-40,floorPos_y-30,trees_x[i]+60,floorPos_y-30);	
	};	
}

// ---------------------------------
// Canyon render and check functions
// ---------------------------------

// Function to draw canyon objects.

function drawCanyon(t_canyon)
{

}

// Function to check character is over a canyon.

function checkCanyon(t_canyon)
{

}

// ----------------------------------
// Collectable items render and check functions
// ----------------------------------

// Function to draw collectable objects.

function drawCollectable(t_collectable)
{
	fill(255,255,0,50);
	ellipse(t_collectable.x_pos,t_collectable.y_pos-20,t_collectable.size);
	fill(55,245,0);
	ellipse(t_collectable.x_pos,t_collectable.y_pos-20,t_collectable.size-25);
}

// Function to check character has collected an item.

function checkCollectable(t_collectable)
{

}
